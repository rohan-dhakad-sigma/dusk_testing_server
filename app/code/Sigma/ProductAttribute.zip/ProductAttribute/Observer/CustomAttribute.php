<?php
namespace Sigma\ProductAttribute\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Checkout\Model\Session as CheckoutSession;
use GuzzleHttp\Client;
use GuzzleHttp\ClientFactory;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\ResponseFactory;
use Magento\Framework\Webapi\Rest\Request;
use Psr\Log\LoggerInterface;

class CustomAttribute implements ObserverInterface
{
    private $responseFactory;
    private $guzzleClient;
    private $_storeManager;
    private $_urlInterface;
    private $logger;

    protected $apiUrl = 'http://duskcloud.com/rest/V1/products/attributes/?searchCriteria';
    protected $adminUsername = "rohan";
    protected $adminPassword = "rohan@123";



    /**
     * CustomAttribute constructor.
     *
     * @param Client $guzzleClient
     * @param ResponseFactory $responseFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\UrlInterface $urlInterface
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(
        Client $guzzleClient,
        ResponseFactory $responseFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\UrlInterface $urlInterface,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->responseFactory = $responseFactory;
        $this->guzzleClient = $guzzleClient;
        $this->_storeManager = $storeManager;
        $this->_urlInterface = $urlInterface;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        try {
            $authorization = 'Bearer m9rjcol36rtn95idxt81a7ge8s5i7hg0';
            $headers = array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'Authorization' => $authorization
            );

            $response = $this->guzzleClient->request('GET', $this->apiUrl, array(
                    'headers' => $headers
                )
            );

            $response = $response->getBody()->getContents();
            $res = json_decode($response, true);
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/API.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
            $logger->info(print_r($res));
        }
        catch(\Excpetion $e) {
            echo $e->getMessage();
        }

    }
}
